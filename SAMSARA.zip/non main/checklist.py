#This will be a choice-based game
#Think of a simple plot
#Make sure a list is used to keep track of the choices the player made
#Assign values to different choices
#An ending will be assigned based on the final value
#Keep the game short and concise to fit within 1 minute
#setting: birthday? daily life? reincarnation? rags to riches?
#create a function to call in order to progress the story 
#i.e event(var1, var2, var3) where the parameters are preset variables
#create function choicetally(choice1, choice2, choice3)
#Good, bad, neutral ending? 
#if final tally is within certain range... then the respective ending will occur
#keep things simple
#append the choices to a list when selected
#maybe use the choices in the list in an if statement to trigger events
